#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from one_c_autoresearch.cli import main
raise SystemExit(main(["manual-cleanup", "build-candidates", *sys.argv[1:]]))
