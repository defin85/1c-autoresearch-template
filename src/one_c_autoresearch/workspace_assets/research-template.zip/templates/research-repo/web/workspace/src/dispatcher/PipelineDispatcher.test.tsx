import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, test, vi } from 'vitest';
import { DispatcherPanel, leaseActionMatrix, PipelineDispatcher, shortWorkId } from './PipelineDispatcher';
import type { DispatcherProjection } from './projection';

const snapshotWithDispatcher = {
  workflow_fingerprint: 'sha256:abc',
  dispatcher: {
    schema_version: '1',
    revision: 7,
    fresh_at: new Date(Date.now() - 1_000).toISOString(),
    circuits: [
      { id: 'prepare-diffs', state: 'complete', aggregates: { diff_count: 145 } },
      { id: 'analyze-dif', state: 'ready', leases: [], aggregates: { customer_diff_count: 75, window_size: 32 } },
      { id: 'form-mrq', state: 'blocked', aggregates: { active_mrq_count: 4, target_batch_count: 4 } },
      { id: 'decide-target', state: 'unknown', aggregates: { decision_count: 0 } },
    ],
    jobs: {},
    items: {
      dif_queue: [{ id: 'DIF-001', path: 'Catalogs/Test.xml', kind: 'extension_intervention', state: 'queued', intervention_kind: 'method_interception', object_scope: 'adopted', target_coverage: 'needs_semantic_review', extension_uuid: '471acdde-293c-497c-bd55-e6ab48d98dc4', component_id: 'target_cf:extension:471acdde-293c-497c-bd55-e6ab48d98dc4', affected_base_identity: 'catalog.products', evidence_count: 2, dependency_count: 1, compatibility_summary: { unresolved: 1 }, blocker_codes: ['unresolved_dependency'] }],
      meaning_diffs: [{ id: 'DIF-002', path: 'Documents/Test.xml', kind: 'changed', state: 'meaning' }],
      noise_diffs: [{ id: 'DIF-003', path: 'Forms/Test.xml', kind: 'changed', state: 'noise' }],
      proposals: [{ id: 'group-1', job_id: 'discover-mrq', kind: 'group.ready', semantic_key: 'orders', dif_ids: ['DIF-002'], evidence_count: 2, noise_count: 0, mrq_id: '', created_at: '2026-07-21T12:00:00Z' }],
      mrqs: [{ id: 'MRQ-014', title: 'Согласование заказа', semantic_key: 'orders', state: 'approved', dif_ids: ['DIF-002'], evidence_count: 2 }],
      batches: [{ id: 'MRQB-1234567890ABCDEF', mrq_ids: ['MRQ-014'], reason: 'orders' }],
      decisions: [{ id: 'MRQ-014', title: 'Согласование заказа', decision: 'adapt', target_solution: 'Адаптировать', evidence_count: 4, gap: true }],
      approval_count: 1,
    },
  },
};

beforeEach(() => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockImplementation((url: string) => {
      if (typeof url === 'string' && url.endsWith('/workflow')) {
        return Promise.resolve({ ok: true, json: async () => snapshotWithDispatcher });
      }
      return Promise.resolve({ ok: true, json: async () => ({ events: [], next_cursor: 0, resync_required: false }) });
    }),
  );
  // EventSource не доступен в jsdom; заглушка, чтобы хук не падал
  vi.stubGlobal('EventSource', class {
    addEventListener() {}
    close() {}
  });
});

afterEach(cleanup);

test('PipelineDispatcher renders four circuits and freshness label', async () => {
  render(<PipelineDispatcher projectId="proj-1" />);
  expect((await screen.findAllByText('Подготовка')).length).toBeGreaterThan(0);
  for (const title of ['Подготовка различий', 'Анализ DIF', 'Формирование MRQ', 'Исследование целевой базы']) {
    expect((await screen.findAllByText(title)).length).toBeGreaterThan(0);
  }
  expect((await screen.findAllByText('DIF-002')).length).toBeGreaterThan(0);
  expect((await screen.findAllByText('MRQ-014')).length).toBeGreaterThan(0);
  expect((await screen.findAllByText('Адаптировать')).length).toBeGreaterThan(0);
  expect(screen.getAllByText(/подтверждено/).length).toBeGreaterThan(0);
  expect(screen.getByText('Легенда')).toBeInTheDocument();
  expect(screen.getByText('Целевая база')).toBeInTheDocument();
  expect(screen.getByText('Классификатор MRQ')).toBeInTheDocument();
  expect(screen.getByText(/method_interception · adopted · needs_semantic_review/)).toBeInTheDocument();
  expect(screen.getByText(/Компонент: target_cf:extension:/)).toBeInTheDocument();
  expect(screen.getByText('Базовый объект: catalog.products')).toBeInTheDocument();
  expect(screen.getAllByText('Доказательств: 2').length).toBeGreaterThan(0);
  expect(screen.getByText('Совместимость: unresolved=1')).toBeInTheDocument();
  expect(screen.getByText('unresolved_dependency')).toBeInTheDocument();
  expect(screen.getByText(/Необработанных физических строк расширений:/)).toBeInTheDocument();
  expect(document.querySelectorAll('[data-stage-state="active"]')).toHaveLength(1);
  expect(document.querySelectorAll('[data-stage-state="future"]')).toHaveLength(4);
});

test('shortWorkId keeps the type and a readable stable prefix', () => {
  expect(shortWorkId('DIF-0083AF4703A5C7DCCA')).toBe('DIF-0083A');
  expect(shortWorkId('MRQ-014')).toBe('MRQ-014');
});

test('PipelineDispatcher does not imitate active workers without a lease', async () => {
  render(<PipelineDispatcher projectId="proj-1" />);
  expect((await screen.findAllByText('Свободен')).length).toBeGreaterThanOrEqual(8);
  expect(screen.queryByText('Анализирует')).not.toBeInTheDocument();
  expect(screen.queryByText('Исследует')).not.toBeInTheDocument();
});

test('PipelineDispatcher shows a soft-stopped lease without imitating work', async () => {
  const lease = { job_id: 'discover-mrq', thread_id: 'thread-1', work_unit_id: 'DIF-001', owner: 'agent-1', acquired_at: new Date().toISOString(), renewed_at: new Date().toISOString(), state: 'resumable', summary: {} };
  const projection = structuredClone(snapshotWithDispatcher.dispatcher) as unknown as DispatcherProjection;
  projection.jobs = { 'discover-mrq': lease };
  projection.circuits[1].leases = [lease];
  render(<PipelineDispatcher projectId="proj-1" initialProjection={projection} initialFingerprint="sha256:abc" />);
  expect((await screen.findAllByText('Остановлен')).length).toBeGreaterThan(0);
  expect(screen.queryByText('Анализирует')).not.toBeInTheDocument();
});

test.each([
  ['absent', undefined, ['start']],
  ['running', 'running', ['stop', 'cancel']],
  ['resumable', 'resumable', ['resume', 'retry', 'cancel']],
  ['blocked', 'blocked', ['cancel', 'approve']],
  ['failed', 'failed', ['retry', 'cancel']],
  ['stale', 'stale', ['retry', 'cancel']],
  ['expired', 'running', ['retry', 'cancel']],
] as const)('lease action matrix: %s', (name, state, enabled) => {
  const now = Date.now();
  const lease = state ? {
    owner: 'agent',
    state,
    work_unit_id: 'DIF-001',
    renewed_at: new Date(name === 'expired' ? now - 31_000 : now).toISOString(),
  } : undefined;
  const matrix = leaseActionMatrix(lease, true, false, true, now);
  expect(Object.entries(matrix).filter(([, value]) => value).map(([key]) => key)).toEqual(enabled);
});

test('panel separates current task and recompute preview before run', async () => {
  const projection = structuredClone(snapshotWithDispatcher.dispatcher) as unknown as DispatcherProjection;
  projection.circuits[1].state = 'complete';
  const fetchMock = vi.mocked(fetch);
  fetchMock.mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);
    if (url.endsWith('/stage-recompute/preview')) {
      return Promise.resolve({
        ok: true,
        json: async () => ({
          boundary: 'diffs',
          plan_fingerprint: 'sha256:plan',
          steps: [{ step_id: '1:diff.build', operation: 'diff.build' }],
          required_confirmations: ['confirm_recompute'],
          possible_result: 'unchanged',
          stop_before: 'mrq.discover-next',
          generations: { source: 'src-1', diff: 'diff-1' },
        }),
      } as Response);
    }
    if (url.endsWith('/stage-recompute/runs')) {
      return Promise.resolve({ ok: true, json: async () => ({ run_id: 'run-1', status: 'running', plan_fingerprint: 'sha256:plan' }) } as Response);
    }
    return Promise.resolve({ ok: true, json: async () => ({}) } as Response);
  });
  render(<DispatcherPanel projectId="proj-1" projection={projection} fingerprint="sha256:workflow" selectedCircuit="analyze-dif" onClose={() => {}} />);
  expect(screen.getByRole('region', { name: 'Текущее задание' })).toBeInTheDocument();
  expect(screen.getByRole('region', { name: 'Пересчёт этапа' })).toBeInTheDocument();
  fireEvent.click(screen.getByRole('button', { name: 'Пересчитать с этапа' }));
  expect(await screen.findByLabelText('Предварительный просмотр пересчёта')).toHaveTextContent('diff.build');
  expect(screen.getByRole('button', { name: 'Запустить пересчёт' })).toBeDisabled();
  fireEvent.click(screen.getByRole('checkbox', { name: 'Подтверждаю: confirm_recompute' }));
  fireEvent.click(screen.getByRole('button', { name: 'Запустить пересчёт' }));
  await waitFor(() => expect(fetchMock).toHaveBeenCalledWith(
    '/api/v1/projects/proj-1/stage-recompute/runs',
    expect.objectContaining({ method: 'POST' }),
  ));
});

test('active recompute disables normal start and has a separate cancel', () => {
  const projection = structuredClone(snapshotWithDispatcher.dispatcher) as unknown as DispatcherProjection;
  projection.jobs['stage-recompute'] = {
    job_id: 'stage-recompute',
    thread_id: 'thread-recompute',
    work_unit_id: 'diffs',
    owner: 'system',
    acquired_at: new Date().toISOString(),
    renewed_at: new Date().toISOString(),
    state: 'running',
    summary: { run_id: 'run-1', current_step: 'diff.build' },
  };
  render(<DispatcherPanel projectId="proj-1" projection={projection} fingerprint="sha256:workflow" selectedCircuit="analyze-dif" onClose={() => {}} />);
  expect(screen.getByRole('button', { name: 'Запустить' })).toBeDisabled();
  expect(screen.getByRole('button', { name: 'Отменить пересчёт' })).toBeEnabled();
  expect(screen.getByText(/Выполняется шаг: diff.build/)).toBeInTheDocument();
  expect(screen.getByText(/временно недоступны/)).toBeInTheDocument();
});

test('MRQ panel guides to explicit actions without reset', () => {
  const projection = structuredClone(snapshotWithDispatcher.dispatcher) as unknown as DispatcherProjection;
  render(<DispatcherPanel projectId="proj-1" projection={projection} fingerprint="sha256:workflow" selectedCircuit="form-mrq" onClose={() => {}} />);
  expect(screen.getByText(/массовый сброс не поддерживается/)).toBeInTheDocument();
  expect(screen.queryByRole('button', { name: 'Пересчитать с этапа' })).not.toBeInTheDocument();
});
